﻿using Data;
using Data.Model;
using Microsoft.EntityFrameworkCore;

namespace Buisness
{
    public class ReaderBuisness
    {
        private readonly ReaderContext readerContext;

        public ReaderBuisness(DbContextOptions<ReaderContext> options)
        {
            readerContext = new ReaderContext(options);
        }

        public List<Reader> GetReaders() => readerContext.Readers.ToList();

        public Reader GetReaderById(int id)
        {
            return readerContext.Readers.Find(id) ?? throw new Exception("Product not found");
        }

        public void AddReader(Reader reader)
        {
            readerContext.Readers.Add(reader);
            readerContext.SaveChanges();
        }

        public void DeleteReader(int id)
        {
            var reader = readerContext.Readers.Find(id) ?? throw new Exception("Book not found!");
            readerContext.Readers.Remove(reader);
            readerContext.SaveChanges();
        }
        public void UpdateReader(Reader reader)
        {
            var oldReader = readerContext.Readers.Find(reader.Id);
            if (oldReader == null)
            {
                throw new Exception("Book not found!");
            }
            oldReader.Name = reader.Name;   
            oldReader.Email = reader.Email;
            oldReader.PhoneNumber = reader.PhoneNumber;
            oldReader.DateRegistration = reader.DateRegistration;
            readerContext.SaveChanges();
        }
    }
}
