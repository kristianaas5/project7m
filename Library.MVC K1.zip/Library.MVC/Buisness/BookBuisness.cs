﻿using Microsoft.EntityFrameworkCore;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Buisness
{
    using Data;
    using Data.Model;
    public class BookBuisness
    {
        private readonly BookContext bookContext;
        public BookBuisness(DbContextOptions<BookContext> options)
        {
            bookContext = new BookContext(options);
        }

        public List<Book> GetBooks() => bookContext.Books.ToList();
        public Book GetBookById(int id)
        {
            return bookContext.Books.Find(id) ?? throw new Exception("Book not found!");
        }
        public void AddBook(Book book)
        {
            bookContext.Books.Add(book);
            bookContext.SaveChanges();
        }
        public void DeleteBook(int id)
        {
            var book = bookContext.Books.Find(id) ?? throw new Exception("Book not found!");
            bookContext.Books.Remove(book);
            bookContext.SaveChanges();
        }
        public void UpdateBook(Book book)
        {
            var oldBook = bookContext.Books.Find(book.Id);
            if (oldBook == null)
            {
                throw new Exception("Book not found!");
            }
            oldBook.Author = book.Author;
            oldBook.Category = book.Category;
            oldBook.Year = book.Year;
            oldBook.Heading = book.Heading;
            bookContext.SaveChanges();
        }
    }
}
