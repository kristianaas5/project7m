using Buisness;
using Data;
using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace Library
{
    public partial class Form1 : Form
    {

        private BookBuisness BookBuisness;
        private ReaderBuisness ReaderBuisness;
        //->
        private int editIdBook = -1, edintIdReader = -1;

        public Form1()
        {
            InitializeComponent();
        }

        string connectionString = ConfigurationManager.ConnectionStrings["Library"].ConnectionString;
        DbContextOptionsBuilder<BookContext> optionsBuilderBooks = new DbContextOptionsBuilder<BookContext>();
        DbContextOptionsBuilder<ReaderContext> optionsBuilderReader = new DbContextOptionsBuilder<ReaderContext>();
        //->



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            label1.Text = "Id";
            textBox1.Visible = true;
            textBox2.Visible = true;
            label2.Visible = true;
            label2.Text = "Reader";
            textBox3.Visible = true;
            label3.Visible = true;
            label3.Text = "Book";
            textBox3.Visible = true;
            label4.Visible = true;
            label4.Text = "Date";
            textBox4.Visible = true;
            label5.Visible = true;
            label5.Text = "Date return";
            textBox5.Visible = true;
            label6.Visible = true;
            label6.Text = "Status";
            textBox6.Visible = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            label1.Text = "Id";
            textBox1.Visible = true;
            label2.Visible = true;
            label2.Text = "Heading";
            textBox2.Visible = true;
            label3.Visible = true;
            label3.Text = "Year";
            textBox3.Visible = true;
            label4.Visible = true;
            label4.Text = "Author";
            textBox4.Visible = true;
            label5.Visible = true;
            label5.Text = "Category";
            textBox5.Visible = true;
            label6.Visible = false;
            textBox6.Visible = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            label1.Text = "Id";
            textBox1.Visible = true;
            label2.Visible = true;
            label2.Text = "Name";
            textBox2.Visible = true;
            label3.Visible = true;
            label3.Text = "Email";
            textBox3.Visible = true;
            label4.Visible = true;
            label4.Text = "Phone number";
            textBox4.Visible = true;
            label5.Visible = true;
            label5.Text = "Date registration";
            textBox5.Visible = true;
            label6.Visible = false;
            textBox6.Visible = false;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            label1.Text = "Id";
            textBox1.Visible = true;
            label2.Visible = true;
            label2.Text = "Name";
            textBox2.Visible = true;
            label3.Visible = true;
            label3.Text = "Date";
            textBox3.Visible = true;
            label4.Visible = true;
            label4.Text = "Description";
            textBox4.Visible = true;
            textBox5.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            textBox6.Visible = false;
        }

        private void UpdateGrid()
        {
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void buttonClose_Click(object sender, EventArgs e) => ActiveForm.Close();

        private void btnInsert_Click(object sender, EventArgs e)
        {
            
            //switch (true)
            //{
            //    case 1: Insert(); break;


            //};
        }

        private int Insert()
        {
            throw new NotImplementedException();
        }
    }
}
