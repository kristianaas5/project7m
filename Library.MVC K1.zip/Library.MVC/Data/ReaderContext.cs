﻿
using Microsoft.EntityFrameworkCore;
using Data.Model;

namespace Data
{
    
    public class ReaderContext: DbContext
    {
        public ReaderContext(DbContextOptions<ReaderContext> options) : base(options) { }
        public DbSet<Reader> Readers { get; set; } = null!;
    }
}
